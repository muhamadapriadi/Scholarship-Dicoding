package com.dicoding.muhamadapriadi.consumerapp

import android.os.Parcelable
import kotlinx.android.parcel.Parcelize

@Parcelize
class Favorite (
    var username: String? = null,
    var avatar: String? = null,
    var hmtl: String? = null,

) : Parcelable