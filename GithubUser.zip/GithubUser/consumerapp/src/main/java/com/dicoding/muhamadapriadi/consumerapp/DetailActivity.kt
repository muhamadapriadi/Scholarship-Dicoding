package com.dicoding.muhamadapriadi.consumerapp

import android.app.AlarmManager
import android.content.ContentValues
import android.content.Intent
import android.net.Uri
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.util.Log
import android.view.Menu
import android.view.MenuItem
import android.view.View
import android.widget.Toast
import androidx.appcompat.app.AlertDialog
import com.bumptech.glide.Glide
import com.bumptech.glide.request.RequestOptions
import com.dicoding.muhamadapriadi.consumerapp.db.UserContract
import com.dicoding.muhamadapriadi.consumerapp.db.UserContract.UserColumns.Companion.CONTENT_URI
import com.dicoding.muhamadapriadi.consumerapp.helper.MappingHelper
import com.loopj.android.http.AsyncHttpClient
import com.loopj.android.http.AsyncHttpResponseHandler
import cz.msebera.android.httpclient.Header
import kotlinx.android.synthetic.main.activity_detail.*
import kotlinx.android.synthetic.main.activity_detail.view.*
import kotlinx.android.synthetic.main.item_row_user.view.*
import org.json.JSONObject
import java.lang.Exception

class DetailActivity : AppCompatActivity(), View.OnClickListener {

    private var isFavorite = false
    private var favorite: Favorite? = null
    private var position: Int = 0
    private lateinit var uriWithId: Uri

    companion object {
        const val EXTRA_USER = "extra_user"
        const val EXTRA_POSITION = "extra_position"
        const val EXTRA_FAVORITE = "extra_favorite"
        private val TAG = DetailActivity::class.java.simpleName

        const val REQUEST_ADD = 100
        const val REQUEST_UPDATE = 200



    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_detail)

        btn_favorite.setOnClickListener(this)



        //holder
        setData()

        //sectionpageradapter
        val user = intent.getParcelableExtra<User>(EXTRA_USER) as User
        val sectionsPagerAdapter = SectionsPagerAdapter(this, supportFragmentManager)
        sectionsPagerAdapter.username = user.username
        view_pager.adapter = sectionsPagerAdapter
        tabs.setupWithViewPager(view_pager)
        supportActionBar?.elevation = 0f

    }

    //dataSearchAPI
    private fun setData() {
        val user = intent.getParcelableExtra<User>(EXTRA_USER) as User
        user.username?.let { getDetailApi(it) }
        Glide.with(this)
            .load(user.avatar)
            .apply(RequestOptions().override(250, 250))
            .into(img_avatar)
        detail_username.text = user.username
        detail_html.text = user.hmtl


    }

    //detailapi
    private fun getDetailApi(username: String) {
        detailprogressBar.visibility = View.VISIBLE
        val url = "https://api.github.com/users/$username"
        val client = AsyncHttpClient()
        client.addHeader("Authorization", "f1928ad3687d8a075653749ee7a61d0ba241f258")
        client.addHeader("User-Agent", "request")
        client.get(url, object : AsyncHttpResponseHandler() {
            override fun onSuccess(
                statusCode: Int,
                headers: Array<Header>,
                responseBody: ByteArray
            ) {
                detailprogressBar.visibility = View.INVISIBLE
                val result = String(responseBody)
                Log.d(TAG, result)
                try {


                    val responseObject = JSONObject(result)

                    val username = responseObject.getString("login")
                    val html = responseObject.getString("html_url")
                    val avatar = responseObject.getString("avatar_url")
                    val location = responseObject.getString("location")
                    val company = responseObject.getString("company")
                    val blog = responseObject.getString("blog")
                    val user = User()
                    user.avatar = avatar
                    user.username = username
                    user.hmtl = html
                    user.location = location
                    user.company = company
                    user.blog = blog

                    detail_location.text = location
                    detail_blog.text = blog
                    detail_company.text = company

                } catch (e: Exception) {
                    e.printStackTrace()
                }
            }


            override fun onFailure(
                statusCode: Int,
                headers: Array<Header>,
                responseBody: ByteArray,
                error: Throwable
            ) {
                detailprogressBar.visibility = View.INVISIBLE

            }


        })
    }

    override fun onClick(view: View) {
        if (view.id == R.id.btn_favorite) {


            val user = intent.getParcelableExtra<User>(EXTRA_USER) as User

            val username = user.username
            val avatar = user.avatar
            val html = user.hmtl

            val intent = Intent()
            intent.putExtra(EXTRA_USER, user)
            intent.putExtra(EXTRA_POSITION, position)

            val values = ContentValues()
            values.put(UserContract.UserColumns.USERNAME, username)
            values.put(UserContract.UserColumns.AVATAR, avatar)
            values.put(UserContract.UserColumns.HTML, html)

            uriWithId = Uri.parse(CONTENT_URI.toString() + "/" + user?.username)

            val cursor = contentResolver.query(uriWithId, null, null, null, null)
            if(cursor?.count!! > 0) {
                isFavorite = true
            }else{
                isFavorite = false
            }


            if (isFavorite) {
                contentResolver.delete(uriWithId, null, null)
                Toast.makeText(this@DetailActivity, "Menghapus Favorit", Toast.LENGTH_SHORT).show()
            } else {
                Log.d(TAG, "result")
                contentResolver.insert(CONTENT_URI, values)
                Toast.makeText(this@DetailActivity, "Menambahkan Favorite", Toast.LENGTH_SHORT).show()
                }
            }
        }



        override fun onCreateOptionsMenu(menu: Menu): Boolean {
            menuInflater.inflate(R.menu.menu_form, menu)
            return super.onCreateOptionsMenu(menu)
        }

        override fun onOptionsItemSelected(item: MenuItem): Boolean {
            when (item.itemId) {
                R.id.menu_favorite -> {
                    val mIntent = Intent(this, UserFavorite::class.java)
                    startActivity(mIntent)
                }
            }
            return super.onOptionsItemSelected(item)
        }
    }
