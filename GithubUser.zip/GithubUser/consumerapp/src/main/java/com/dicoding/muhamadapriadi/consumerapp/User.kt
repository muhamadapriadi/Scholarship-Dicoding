package com.dicoding.muhamadapriadi.consumerapp

import android.os.Parcelable
import kotlinx.android.parcel.Parcelize

@Parcelize
class User (
    var username: String? = null,
    var avatar: String? = null,
    var location: String? = null,
    var hmtl: String? = null,
    var company: String? = null,
    var blog: String? = null

) : Parcelable