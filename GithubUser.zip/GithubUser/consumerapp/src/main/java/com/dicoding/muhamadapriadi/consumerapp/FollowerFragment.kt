package com.dicoding.muhamadapriadi.consumerapp

import android.os.Bundle
import android.util.Log
import androidx.fragment.app.Fragment
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.loopj.android.http.AsyncHttpClient
import com.loopj.android.http.AsyncHttpResponseHandler
import cz.msebera.android.httpclient.Header
import kotlinx.android.synthetic.main.activity_main.*
import kotlinx.android.synthetic.main.fragment_follower.*
import org.json.JSONArray
import org.json.JSONObject
import java.lang.Exception


class FollowerFragment : Fragment() {


    private lateinit var adapter: ListUserAdapter



    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?): View? {


        return inflater.inflate(R.layout.fragment_follower, container, false)
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?){
        super.onViewCreated(view, savedInstanceState)

        val username = arguments?.getString(ARG_USERNAME)

        followerRecyclerView.setHasFixedSize(true)

        adapter = ListUserAdapter()
        adapter.notifyDataSetChanged()

        followerRecyclerView.layoutManager = LinearLayoutManager(activity)
        followerRecyclerView.adapter = adapter

        val url = "https://api.github.com/users/$username/followers"
        val client = AsyncHttpClient()
        client.addHeader("Authorization", "f1928ad3687d8a075653749ee7a61d0ba241f258")
        client.addHeader("User-Agent", "request")
        client.get(url, object : AsyncHttpResponseHandler() {
            override fun onSuccess(statusCode: Int, headers: Array<Header>, responseBody: ByteArray) {
                val result = String(responseBody)
                Log.d(TAG, result)
                val listData: ArrayList<User> = ArrayList()
                try {



                    val items = JSONArray(result)

                    for (i in 0 until items.length()) {
                        val item = items.getJSONObject(i)
                        val username = item.getString("login")
                        val html = item.getString("html_url")
                        val avatar = item.getString("avatar_url")
                        val user = User()
                        user.avatar = avatar
                        user.hmtl = html
                        user.username = username
                        listData.add(user)

                    }
                    adapter.setData(listData)


                } catch (e: Exception) {
                    e.printStackTrace()
                }
            }

            override fun onFailure(
                statusCode: Int,
                headers: Array<Header>,
                responseBody: ByteArray,
                error: Throwable
            ) {
            }

        })

    }



    companion object {

        private val ARG_USERNAME = "username"
        private val TAG = FollowerFragment::class.java.simpleName


        fun newInstance(username: String?): FollowerFragment{
            val fragment = FollowerFragment()
            val bundle = Bundle()
            bundle.putString(ARG_USERNAME, username)
            fragment.arguments = bundle
            return fragment
                }
            }
    }

