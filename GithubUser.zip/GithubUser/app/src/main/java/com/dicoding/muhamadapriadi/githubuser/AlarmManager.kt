package com.dicoding.muhamadapriadi.githubuser

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle


class AlarmManager : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_alarm_manager)

        supportFragmentManager.beginTransaction().add(R.id.alarm_holder, MyPreferenceFragment())
            .commit()
    }
}