package com.dicoding.muhamadapriadi.githubuser

import android.content.Intent
import android.database.ContentObserver
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.os.Handler
import android.os.HandlerThread
import androidx.recyclerview.widget.LinearLayoutManager
import com.dicoding.muhamadapriadi.githubuser.adapter.UserAdapter
import com.dicoding.muhamadapriadi.githubuser.db.UserContract.UserColumns.Companion.CONTENT_URI
import com.dicoding.muhamadapriadi.githubuser.db.UserHelper
import com.dicoding.muhamadapriadi.githubuser.helper.MappingHelper
import com.google.android.material.snackbar.Snackbar
import kotlinx.android.synthetic.main.activity_detail.*
import kotlinx.android.synthetic.main.activity_main.*
import kotlinx.android.synthetic.main.activity_user_favorite.*
import kotlinx.coroutines.*

class UserFavorite : AppCompatActivity(){

    private lateinit var adapter: UserAdapter


    companion object{
        private const val EXTRA_STATE = "extra_state"
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_user_favorite)

        favoriteRecyclerView.layoutManager = LinearLayoutManager(this)
        favoriteRecyclerView.setHasFixedSize(true)
        adapter = UserAdapter(this)
        favoriteRecyclerView.adapter = adapter

       favoriteRecyclerView.setOnClickListener{
            val intent = Intent(this@UserFavorite, DetailActivity::class.java)
            startActivityForResult(intent, DetailActivity.REQUEST_ADD)
        }

        val handlerThread = HandlerThread("DataObserver")
        handlerThread.start()
        val handler = Handler(handlerThread.looper)

        val myObserver = object : ContentObserver(handler) {
            override fun onChange(self: Boolean) {
                loadNotesAsync()
            }
        }

        contentResolver.registerContentObserver(CONTENT_URI, true, myObserver)

        if (savedInstanceState == null) {
            loadNotesAsync()
        } else {
            savedInstanceState.getParcelableArrayList<Favorite>(EXTRA_STATE)?.also { adapter.listFavorite = it }

        }
    }

    private fun loadNotesAsync() {
        GlobalScope.launch(Dispatchers.Main) {

            val deferredFavorite = async(Dispatchers.IO) {
                val cursor = contentResolver.query(CONTENT_URI, null, null, null, null)
                MappingHelper.mapCursorToArrayList(cursor)
            }
            val favorite = deferredFavorite.await()
            if (favorite.size > 0) {
                adapter.listFavorite = favorite
            } else {
                adapter.listFavorite = ArrayList()
                showSnackbarMessage("Tidak ada data saat ini")
            }
        }
    }

    override fun onSaveInstanceState(outState: Bundle) {
        super.onSaveInstanceState(outState)
        outState.putParcelableArrayList(EXTRA_STATE, adapter.listFavorite)
    }

    private fun showSnackbarMessage(message: String) {
        Snackbar.make(favoriteRecyclerView, message, Snackbar.LENGTH_SHORT).show()
    }

  }