package com.dicoding.muhamadapriadi.githubuser.helper

import android.database.Cursor
import com.dicoding.muhamadapriadi.githubuser.Favorite
import com.dicoding.muhamadapriadi.githubuser.User
import com.dicoding.muhamadapriadi.githubuser.db.UserContract

object MappingHelper {

    fun mapCursorToArrayList(userCursor: Cursor?): ArrayList<Favorite> {
        val favoriteList = ArrayList<Favorite>()
        userCursor?.apply {
            while (moveToNext()) {
                val username = getString(getColumnIndexOrThrow(UserContract.UserColumns.USERNAME))
                val avatar = getString(getColumnIndexOrThrow(UserContract.UserColumns.AVATAR))
                val html = getString(getColumnIndexOrThrow(UserContract.UserColumns.HTML))


                favoriteList.add(Favorite( username, avatar, html))
            }
        }
        return favoriteList
    }

    fun mapCursorToObject(userCursor: Cursor?): Favorite {
        var favorite = Favorite()
        userCursor?.apply {
            moveToFirst()
            val username = getString(getColumnIndexOrThrow(UserContract.UserColumns.USERNAME))
            val avatar = getString(getColumnIndexOrThrow(UserContract.UserColumns.AVATAR))
            val html = getString(getColumnIndexOrThrow(UserContract.UserColumns.HTML))
            favorite = Favorite(username, avatar, html)
        }
        return favorite
    }
}