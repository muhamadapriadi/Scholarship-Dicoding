package com.dicoding.muhamadapriadi.githubuser

import android.content.Context
import android.content.SharedPreferences
import android.os.Bundle
import androidx.preference.PreferenceFragmentCompat
import androidx.preference.SwitchPreference
import com.dicoding.muhamadapriadi.githubuser.alarm.AlarmReceiver

class MyPreferenceFragment : PreferenceFragmentCompat(), SharedPreferences.OnSharedPreferenceChangeListener {

    private lateinit var ALARM: String

    private lateinit var AlarmPreference: SwitchPreference

    private lateinit var alarmReceiver: AlarmReceiver

    companion object {
        private const val DEFAULT_VALUE = "Tidak Ada"
    }

    override fun onCreatePreferences(bundle: Bundle?, s: String?) {
        addPreferencesFromResource(R.xml.preferences)

        init()
    }

    override fun onResume() {
        super.onResume()
        preferenceScreen.sharedPreferences.registerOnSharedPreferenceChangeListener(this)
    }

    override fun onPause() {
        super.onPause()
        preferenceScreen.sharedPreferences.unregisterOnSharedPreferenceChangeListener(this)
    }

    override fun onSharedPreferenceChanged(sharedPreferences: SharedPreferences, key: String) {
        if(key == ALARM){
            if(sharedPreferences.getBoolean(ALARM, false)){
                alarmReceiver.setRepeatingAlarm(context as Context, "09:00",
                    getString(R.string.kembali),
                    getString(R.string.set_repeating_alarm))
            } else{
                alarmReceiver.cancelAlarm(context as Context,
                    getString(R.string.cancel_alarm))
            }
        }
    }



    private fun init() {
        ALARM = resources.getString(R.string.key_alarm)

        AlarmPreference = findPreference<SwitchPreference> (ALARM) as SwitchPreference

        alarmReceiver = AlarmReceiver()

    }
}
