package com.dicoding.muhamadapriadi.academy.data

data class ContentEntity(
    var content: String?
)