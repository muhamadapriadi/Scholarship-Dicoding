package com.dicoding.muhamadapriadi.githubuser

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.util.Log
import android.view.View
import android.widget.Toast
import com.bumptech.glide.Glide
import com.bumptech.glide.request.RequestOptions
import com.loopj.android.http.AsyncHttpClient
import com.loopj.android.http.AsyncHttpResponseHandler
import cz.msebera.android.httpclient.Header
import kotlinx.android.synthetic.main.activity_detail.*
import kotlinx.android.synthetic.main.activity_detail.view.*
import kotlinx.android.synthetic.main.item_row_user.view.*
import org.json.JSONObject
import java.lang.Exception

class DetailActivity : AppCompatActivity() {


    companion object {
        const val EXTRA_USER = "extra_user"
        private val TAG = DetailActivity::class.java.simpleName

    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_detail)

        setData()

        val user = intent.getParcelableExtra<User>(EXTRA_USER) as User
        val sectionsPagerAdapter = SectionsPagerAdapter(this, supportFragmentManager)
        sectionsPagerAdapter.username = user.username
        view_pager.adapter = sectionsPagerAdapter
        tabs.setupWithViewPager(view_pager)
        supportActionBar?.elevation = 0f



        }
    

    private fun setData(){
        val user = intent.getParcelableExtra<User>(EXTRA_USER) as User
        user.username?.let { getDetailApi(it) }
        Glide.with(this)
            .load(user.avatar)
            .apply(RequestOptions().override(250,250))
            .into(img_avatar)
        detail_username.text = user.username
        detail_html.text = user.hmtl



    }

        private fun getDetailApi(username: String) {
            detailprogressBar.visibility = View.VISIBLE
            val url = "https://api.github.com/users/$username"
            val client = AsyncHttpClient()
            client.addHeader("Authorization", "f1928ad3687d8a075653749ee7a61d0ba241f258")
            client.addHeader("User-Agent", "request")
            client.get(url, object : AsyncHttpResponseHandler() {
                override fun onSuccess(statusCode: Int, headers: Array<Header>, responseBody: ByteArray) {
                    detailprogressBar.visibility = View.INVISIBLE
                    val result = String(responseBody)
                    Log.d(TAG, result)
                    try {


                        val responseObject = JSONObject(result)

                            val username = responseObject.getString("login")
                            val html = responseObject.getString("html_url")
                            val avatar = responseObject.getString("avatar_url")
                            val location = responseObject.getString("location")
                            val company = responseObject.getString("company")
                            val blog = responseObject.getString("blog")
                            val user = User()
                            user.avatar = avatar
                            user.username = username
                            user.hmtl = html
                            user.location = location
                            user.company = company
                            user.blog = blog

                            detail_location.text = location
                            detail_blog.text = blog
                            detail_company.text = company

                        }
                    catch (e: Exception) {
                        e.printStackTrace()
                    }
                }


                override fun onFailure(statusCode: Int, headers: Array<Header>, responseBody: ByteArray, error: Throwable) {
                    detailprogressBar.visibility = View.INVISIBLE

                }


        })
        }
    }
