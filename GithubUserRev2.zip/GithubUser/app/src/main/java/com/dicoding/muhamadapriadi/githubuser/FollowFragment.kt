package com.dicoding.muhamadapriadi.githubuser

import android.os.Bundle
import android.util.Log
import androidx.fragment.app.Fragment
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.recyclerview.widget.LinearLayoutManager
import com.loopj.android.http.AsyncHttpClient
import com.loopj.android.http.AsyncHttpResponseHandler
import cz.msebera.android.httpclient.Header
import kotlinx.android.synthetic.main.fragment_follow.*
import kotlinx.android.synthetic.main.fragment_follower.*
import kotlinx.android.synthetic.main.fragment_follower.followerRecyclerView
import org.json.JSONArray
import java.lang.Exception


class FollowFragment : Fragment() {

    private lateinit var adapter: ListUserAdapter




    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View? {
        // Inflate the layout for this fragment
        return inflater.inflate(R.layout.fragment_follow, container, false)
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?){
        super.onViewCreated(view, savedInstanceState)

        val username = arguments?.getString(ARG_USERNAME)

        followRecyclerView.setHasFixedSize(true)

        adapter = ListUserAdapter()
        adapter.notifyDataSetChanged()

        followRecyclerView.layoutManager = LinearLayoutManager(activity)
        followRecyclerView.adapter = adapter

        followprogressBar.visibility = View.VISIBLE
        val url = "https://api.github.com/users/$username/following"
        val client = AsyncHttpClient()
        client.addHeader("Authorization", "f1928ad3687d8a075653749ee7a61d0ba241f258")
        client.addHeader("User-Agent", "request")

        client.get(url, object : AsyncHttpResponseHandler() {
            override fun onSuccess(statusCode: Int, headers: Array<Header>, responseBody: ByteArray) {
                followprogressBar.visibility = View.INVISIBLE
                val result = String(responseBody)
                Log.d(TAG, result)
                val listData: ArrayList<User> = ArrayList()
                try {



                    val items = JSONArray(result)

                    for (i in 0 until items.length()) {
                        val item = items.getJSONObject(i)
                        val username = item.getString("login")
                        val html = item.getString("html_url")
                        val avatar = item.getString("avatar_url")
                        val user = User()
                        user.avatar = avatar
                        user.hmtl = html
                        user.username = username
                        listData.add(user)

                    }
                    adapter.setData(listData)


                } catch (e: Exception) {
                    e.printStackTrace()
                }
            }

            override fun onFailure(
                statusCode: Int,
                headers: Array<Header>,
                responseBody: ByteArray,
                error: Throwable
            ) {
                followprogressBar.visibility = View.INVISIBLE
            }

        })
    }


    companion object {
        private val ARG_USERNAME = "username"
        private val TAG = FollowFragment::class.java.simpleName


        fun newInstance(username: String?): FollowFragment{
            val fragment = FollowFragment()
            val bundle = Bundle()
            bundle.putString(ARG_USERNAME, username)
            fragment.arguments = bundle
            return fragment
        }

    }
}