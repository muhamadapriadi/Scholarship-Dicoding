package com.dicoding.muhamadapriadi.githubuser


import android.app.SearchManager
import android.content.Context
import android.content.Intent
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.util.Log
import android.view.Menu
import android.view.View
import android.widget.*
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView

import com.loopj.android.http.AsyncHttpClient
import com.loopj.android.http.AsyncHttpResponseHandler
import cz.msebera.android.httpclient.Header
import kotlinx.android.synthetic.main.activity_detail.*
import kotlinx.android.synthetic.main.activity_main.*
import kotlinx.android.synthetic.main.activity_main.progressBar
import kotlinx.android.synthetic.main.item_row_user.*
import org.json.JSONObject
import java.lang.Exception

class MainActivity : AppCompatActivity() {

    private val list = ArrayList<User>()

    private lateinit var adapter: ListUserAdapter

    companion object {
        private val TAG = MainActivity::class.java.simpleName
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)


        recyclerView.setHasFixedSize(true)

        adapter = ListUserAdapter()
        adapter.notifyDataSetChanged()


        recyclerView.layoutManager = LinearLayoutManager(this)
        recyclerView.adapter = adapter




        showRecyclerList()
    }


    override fun onCreateOptionsMenu(menu: Menu): Boolean {
        val inflater = menuInflater
        inflater.inflate(R.menu.options_menu, menu)

        val searchManager = getSystemService(Context.SEARCH_SERVICE) as SearchManager
        val searchView = menu.findItem(R.id.search).actionView as SearchView

        searchView.setSearchableInfo(searchManager.getSearchableInfo(componentName))
        searchView.queryHint = resources.getString(R.string.search_hint)

        searchView.setOnQueryTextListener(object : SearchView.OnQueryTextListener {

            override fun onQueryTextSubmit(query: String): Boolean {
                Toast.makeText(this@MainActivity, query, Toast.LENGTH_SHORT).show()
                getDataUserFromApi(query)
                return true
            }

            override fun onQueryTextChange(newText: String): Boolean {
                return false
            }
        })
        return true
    }


    private fun showRecyclerList(){


        adapter.setOnItemClickCallback(object : ListUserAdapter.OnItemClickCallback{
          override fun onItemClicked(data: User) {
              val moveIntent = Intent(this@MainActivity, DetailActivity::class.java)
              moveIntent.putExtra(DetailActivity.EXTRA_USER, data)
              startActivity(moveIntent)

            }
        })
    }





    private fun getDataUserFromApi(username: String) {
       progressBar.visibility = View.VISIBLE
       textView.visibility = View.VISIBLE
       val url = "https://api.github.com/search/users?q=$username"
       val client = AsyncHttpClient()
       client.addHeader("Authorization", "f1928ad3687d8a075653749ee7a61d0ba241f258")
       client.addHeader("User-Agent", "request")
       client.get(url, object : AsyncHttpResponseHandler() {
           override fun onSuccess(statusCode: Int, headers: Array<Header>, responseBody: ByteArray) {
               progressBar.visibility = View.INVISIBLE
               textView.visibility = View.INVISIBLE
               val listData: ArrayList<User> = ArrayList()
               try {

                   val result = String(responseBody)
                   Log.d(TAG, result)
                   val responseObject = JSONObject(result)
                   val items = responseObject.getJSONArray("items")

                   for (i in 0 until items.length()) {
                       val item = items.getJSONObject(i)
                       val username = item.getString("login")
                       val html = item.getString("html_url")
                       val avatar = item.getString("avatar_url")
                       val user = User()
                       user.avatar = avatar
                       user.username = username
                       user.hmtl = html

                       listData.add(user)

                   }
                   adapter.setData(listData)



               } catch (e: Exception) {
                   e.printStackTrace()
               }
           }



           override fun onFailure(statusCode: Int, headers: Array<Header>, responseBody: ByteArray, error: Throwable) {
               progressBar.visibility = View.INVISIBLE
               textView.visibility = View.INVISIBLE

           }

       })
   }

}